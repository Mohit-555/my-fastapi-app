from fastapi import APIRouter, Depends, HTTPException, Request
from app.limiter import limiter
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.database import get_db
from app.models.models import RefreshToken, User
from app.models.schemas import (
    UserRegisterRequest, UserLoginRequest,
    LogoutRequest, LogoutResponse, RefreshTokenRequest,
    LoginResponse, TokenResponse, UserResponse, ChangePasswordRequest
)
from app.auth_utils import (
    hash_password, verify_password, create_access_token, create_refresh_token,
    hash_refresh_token,
    get_current_user,
    ACCESS_TOKEN_EXPIRE_MINUTES, REFRESH_TOKEN_EXPIRE_DAYS, REMEMBER_ME_EXPIRE_DAYS
)

router = APIRouter(prefix="/auth", tags=["Auth"])


def _issue_tokens(user: User, db: Session, remember_me: bool = False) -> TokenResponse:
    access_expire = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    refresh_expire = (
        timedelta(days=REMEMBER_ME_EXPIRE_DAYS)
        if remember_me
        else timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    )
    refresh_token = create_refresh_token()
    db.add(RefreshToken(
        user_id=user.id,
        token_hash=hash_refresh_token(refresh_token),
        remember_me=remember_me,
        expires_at=datetime.utcnow() + refresh_expire,
    ))
    db.commit()

    return TokenResponse(
        access_token=create_access_token({"sub": user.employee_id}, access_expire),
        refresh_token=refresh_token,
        expires_in=int(access_expire.total_seconds()),
    )


@router.post("/register", response_model=UserResponse, status_code=201)
@limiter.limit("5/minute")
def register(request: Request, payload: UserRegisterRequest, db: Session = Depends(get_db)):
    if payload.password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    if db.query(User).filter(User.employee_id == payload.employee_id).first():
        raise HTTPException(status_code=400, detail="Employee ID already registered")

    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
    full_name=payload.full_name,
    employee_id=payload.employee_id,
    designation=payload.designation,
    role_id=payload.role_id,
    zone_id=payload.zone_id,
    division_id=payload.division_id,
    mobile_number=payload.mobile_number,
    email=payload.email,
    hashed_password=hash_password(payload.password),
    reporting_officer_id=payload.reporting_officer_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=LoginResponse)
@limiter.limit("5/minute")
def login(request: Request, payload: UserLoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.employee_id == payload.employee_id).first()

    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid employee ID or password")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is deactivated. Contact admin.")

    tokens = _issue_tokens(user, db, payload.remember_me)
    return {
        "status": True,
        "message": "Login successful",
        "data": {
            "token": tokens.access_token,
            "refresh_token": tokens.refresh_token,
            "user": {
                "id": user.id,
                "employee_id": user.employee_id,
                "fullName": user.full_name,
                "role": user.role_id,
                "email": user.email,
                "designation": user.designation,
                "zone_id": user.zone_id,
                "division_id": user.division_id,
                "mobile_number": user.mobile_number,
                "reporting_officer_id": user.reporting_officer_id,
                "zone_name": user.zone.zone_name if user.zone else None,
                "zone_code": user.zone.zone_code if user.zone else None,
                "division_name": user.division.division_name if user.division else None,
                "division_code": user.division.division_code if user.division else None,
                "role_name": user.role.name if user.role else None,
                "role_display_name": user.role.display_name if user.role else None,
            },
        },
    }



@router.post("/refresh", response_model=TokenResponse)
@limiter.limit("10/minute")
def refresh(request: Request, payload: RefreshTokenRequest, db: Session = Depends(get_db)):
    token_hash = hash_refresh_token(payload.refresh_token)
    refresh_token = db.query(RefreshToken).filter(RefreshToken.token_hash == token_hash).first()

    if (
        not refresh_token
        or refresh_token.revoked_at is not None
        or refresh_token.expires_at <= datetime.utcnow()
    ):
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

    user = db.query(User).filter(User.id == refresh_token.user_id).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found or inactive")

    refresh_token.revoked_at = datetime.utcnow()
    db.commit()
    return _issue_tokens(user, db, remember_me=refresh_token.remember_me)


@router.post("/logout", response_model=LogoutResponse)
def logout(payload: LogoutRequest, db: Session = Depends(get_db)):
    token_hash = hash_refresh_token(payload.refresh_token)
    refresh_token = db.query(RefreshToken).filter(RefreshToken.token_hash == token_hash).first()

    if refresh_token and refresh_token.revoked_at is None:
        refresh_token.revoked_at = datetime.utcnow()
        db.commit()

    return LogoutResponse(message="Logged out successfully")


@router.get("/me", response_model=UserResponse)
def get_me(
    current_user: User = Depends(get_current_user),
):
    return {
        "id": current_user.id,
        "full_name": current_user.full_name,
        "employee_id": current_user.employee_id,
        "designation": current_user.designation,
        "role_id": current_user.role_id,
        "zone_id": current_user.zone_id,
        "division_id": current_user.division_id,
        "email": current_user.email,
        "mobile_number": current_user.mobile_number,
        "reporting_officer_id": current_user.reporting_officer_id,
        "is_active": current_user.is_active,
        "created_at": current_user.created_at,
        "zone_name": current_user.zone.zone_name if current_user.zone else None,
        "zone_code": current_user.zone.zone_code if current_user.zone else None,
        "division_name": current_user.division.division_name if current_user.division else None,
        "division_code": current_user.division.division_code if current_user.division else None,
        "role_name": current_user.role.name if current_user.role else None,
        "role_display_name": current_user.role.display_name if current_user.role else None,
    }



@router.post("/change-password")
@limiter.limit("5/minute")
def change_my_password(
    request: Request,
    payload: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Change the logged in user's password."""
    if not verify_password(payload.current_password, current_user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    if payload.new_password != payload.confirm_new_password:
        raise HTTPException(status_code=400, detail="New passwords do not match")
    current_user.hashed_password = hash_password(payload.new_password)
    db.commit()
    db.refresh(current_user)
    return {"status": True, "message": "Password updated successfully"}

