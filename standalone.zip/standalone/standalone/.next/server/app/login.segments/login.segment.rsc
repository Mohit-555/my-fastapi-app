1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/3ry7przrutpz1.js","/_next/static/chunks/0s49a5_ed6ii0.js","/_next/static/chunks/0wqmb2jvzgh7v.js","/_next/static/chunks/2sd4lalruoi4v.js"],"default"]
3:I[37457,["/_next/static/chunks/3ry7przrutpz1.js","/_next/static/chunks/0s49a5_ed6ii0.js","/_next/static/chunks/0wqmb2jvzgh7v.js","/_next/static/chunks/2sd4lalruoi4v.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"JUb-Nj7kyXcH7_IaIa_Kt"}
