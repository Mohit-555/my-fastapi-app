module.exports=[89091,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_admin_system-configuration_assets-types_page_actions_1ej2i-3.js.map