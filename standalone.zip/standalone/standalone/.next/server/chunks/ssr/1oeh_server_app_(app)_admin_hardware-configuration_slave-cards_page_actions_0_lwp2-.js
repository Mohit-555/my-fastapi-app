module.exports=[34007,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_admin_hardware-configuration_slave-cards_page_actions_0_lwp2-.js.map