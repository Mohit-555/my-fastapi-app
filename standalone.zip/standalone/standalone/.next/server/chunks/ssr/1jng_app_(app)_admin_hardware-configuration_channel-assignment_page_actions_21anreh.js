module.exports=[79516,(a,b,c)=>{}];

//# sourceMappingURL=1jng_app_%28app%29_admin_hardware-configuration_channel-assignment_page_actions_21anreh.js.map