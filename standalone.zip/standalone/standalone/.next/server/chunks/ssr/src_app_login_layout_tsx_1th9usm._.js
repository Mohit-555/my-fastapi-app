module.exports=[67357,a=>{"use strict";a.s(["default",0,function({children:a}){return a}])},49384,a=>{a.n(a.i(67357))}];

//# sourceMappingURL=src_app_login_layout_tsx_1th9usm._.js.map